#!/usr/bin/env python3
"""Read-only selection of critical Study A yearly CSVs for further time-series analysis.

Runs in Miniforge Prompt, no solver or GitLab dependency. Deliberately collects
only selected annual cases, not hundreds of full-year results.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

AC_CASES = (
    'A1_106039_ss90_ref_mapped_optimized_pf098_length10_annual8760',
    'A1_106039_ss90_ref_mapped_causal_pf098_length10_annual8760',
    'A1_106039_ss90_ref_mapped_optimized_pf095_length16_annual8760',
    'A1_106039_min_cost_ref_mapped_optimized_pf098_length10_annual8760',
    'A1_113699_min_cost_ref_mapped_optimized_pf098_length10_annual8760',
    'A0_94022_ss90_ref_mapped_optimized_pf098_length10_annual8760',
    'A0_92395_min_cost_four_mst_optimized_pf095_length16_annual8760',
    'A0_92395_min_cost_four_star_optimized_pf095_length16_annual8760',
    'A0_92395_ss90_four_mst_optimized_pf095_length16_annual8760',
    'A0_92395_ss90_four_star_optimized_pf095_length16_annual8760',
)
ENERGY_CASES = (
    'A1_106039_ss90_ref', 'A1_106039_min_cost_ref',
    'A0_94022_ss90_ref',
    'A0_92395_min_cost_four','A0_92395_ss90_four',
    'A0_113699_ss90_ref','A0_85398_ss90_ref',
)

def long_path(p):
    p=Path(p).resolve()
    if os.name!='nt': return p
    s=str(p)
    if s.startswith('\\\\?\\'): return p
    if s.startswith('\\\\'):return Path('\\\\?\\UNC\\'+s[2:])
    return Path('\\\\?\\'+s)

def read_bytes(p):
    return long_path(p).read_bytes()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo-root',type=Path,default=Path('.'))
    parser.add_argument('--out',type=Path,default=Path('StudyA_Selected_Annual_Hourly_Evidence.zip'))
    args=parser.parse_args()
    repo=args.repo_root.resolve()
    root=repo/'case1/studies/SEEDExchange_StudyA_v6_LocalRunner/outputs/run_01/pvbess_phase_01'
    output=args.out.resolve()
    if output.exists():raise SystemExit(f'Output exists; choose a new --out path: {output}')
    log=[]; files=[]
    for case in AC_CASES:
        folder=root/'annual_ac_replays_v1'/case
        files.append((folder/'ac_summary.json',folder/'ac_hourly.csv','ac_hourly_sha256'))
    for case in ENERGY_CASES:
        files.append((root/('energy_'+case)/'energy_manifest.json',root/('energy_'+case)/'energy_hourly_2025.csv','energy_csv_sha256'))
        files.append((root/('causal_'+case)/'causal_summary.json',root/('causal_'+case)/'causal_pv_first_2025.csv','output_sha256'))
    with ZipFile(output,'w',ZIP_DEFLATED,compresslevel=6) as z:
        for meta, data, hashfield in files:
            try:
                meta_bytes=read_bytes(meta)
                values=json.loads(meta_bytes)
                data_bytes=read_bytes(data)
                # Manifest layouts: direct for AC/energy, direct for causal
                want=values.get(hashfield)
                actual=hashlib.sha256(data_bytes).hexdigest()
                if not want or want!=actual:
                    raise ValueError(f'signed SHA-256 mismatch: expected {want}, actual {actual}')
                for path,payload in ((meta,meta_bytes),(data,data_bytes)):
                    arcname=path.relative_to(root).as_posix()
                    z.writestr(arcname,payload)
                log.append({'case':data.parent.name,'status':'INCLUDED_SIGNED','bytes':len(data_bytes),'sha256':actual})
            except Exception as ex:
                log.append({'case':data.parent.name,'status':'ERROR','reason':str(ex)})
        z.writestr('SELECTED_EVIDENCE_MANIFEST.json',json.dumps({'cases':log,'all_selected_valid':all(x['status']=='INCLUDED_SIGNED' for x in log),'selection':'Targeted electrical violations, topology stress and monthly/PV/BESS profiles. Not the full annual portfolio.'},indent=2)+'\n')
    print('Selected evidence ZIP:',output)
    print('Verified selected annual case files:',sum(x['status']=='INCLUDED_SIGNED' for x in log),'/',len(log))
    print('Reported errors:',[x for x in log if x['status']!='INCLUDED_SIGNED'])
    print('ZIP size MB:',round(output.stat().st_size/1e6,2))

if __name__=='__main__':main()
