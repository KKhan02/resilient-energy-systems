# SEEDExchange, Study A: annual PV+BESS final portfolio research review

**Date:** 16 November 2026  
**Scope:** all 22 fixed-hardware/new-four-house annual PyPSA cases, 22 causal dispatches, and 432 annual balanced-AC replays at 2025 hourly resolution.  
**Original evidence:** user-supplied `StudyA_PVBESS_Annual_Result_Summary_FINAL.zip`, matched to the previously audited 90-case gross-AC study. No new numerical power-flow or optimization run was executed in this review. GitLab and historical models were not changed.

## 1. Completeness, provenance, and corrected collector anomaly

- The compact collector archive includes **476 distinct full-year case records**: 22 optimized energy, 22 causal, 432 AC.
- The collector reports an existing summary, existing hourly file, 8,760 unique consecutive 2025 hours, and matching source-signed SHA-256 checksums for **all 476**. Every one of the 432 AC summary records reports 8,760 converged and zero nonconverged hours. This review independently checked their aggregate identities and all 432 unique case names against the ZIP's original summary JSONs; raw hourly files are **not bundled in the compact archive**, so the hourly physics has **not been independently re-executed or reread in this review**.
- The original `COLLECTION_REPORT.json` counted only **360/432** AC runs under `signed_chronology_verified` and reported **72 `DUPLICATE_AC_DIMENSIONS`**. This is a **collector grouping/identity error**: it collapses the new `four` hardware into historical `ref` at A0 113699 and 85398 for both tiers, both dispatch modes and nine sensitivity points. These are **72 rows belonging to 36 distinct two-way groups**. Preserving `hardware_family=archived_reference/four_house_new` yields **432/432 unique dimension keys** with a complete 48 design/dispatch x 9 PF/length coverage. The 72 flagged rows still had valid collector-signed hourly data. No rerun is warranted for this metadata problem.
- The collector also omitted `tier` for six new-four-house causal cases; it can be reconstructed without ambiguity from the explicit case IDs. It omitted cost values for six four-house energy cases although their signed `energy_manifest.json` includes the new optimization's `model_summary.annual_total_usd`. All six annual costs were recovered from those original saved manifests, **not estimated**. Two new-four-house cost and power distinctions must remain separate from borrowed historical references.
- Eight AC summaries include explicit recovery provenance after an interrupted Windows path-length-related output failure. Hourly CSVs were preserved unchanged according to their recovery metadata.
- One signed input manifest SHA-256 is consistent across gross, energy, causal and AC results: `2ff7eb9c1f28f12efc11aca9b366e5277da72a62f6d7709f47dc3841b6e71d69`.

## 2. Best matched baseline comparison, 34 households

Five transformer territories cover **34/35** candidate households. The one support-only household at 98380 is excluded from the >=4-house multi-house optimization and is **not** a hidden sixth installation. The 92395 proposed STAR network uses exactly the same four household members in both A0 and A1 and so has one set of independently simulated physical configurations; it is included once in each aggregate 34-house reference for **comparison**, not counted as an extra A1 AC run. A0/A1 all share the same 34 distinct households and total synthetic demand **64,532 kWh/2025**.

The following rows compare the *same cohort assignments, PF=0.98, service length factor=1.0*, with the same 92395 STAR network. For PV+BESS: `archived_reference` hardware for the four geographically mapped territories, new `four_house_new` hardware for 92395, with **optimized** 8,760-hour operation. Every count is a **sum of transformer-territory violation hours**, **not** a count of distinct community-wide clock hours. The underlying gross-demand baseline is included only once in each row.

| Grouping | Gross-load AC violation territory-hours | Minimum-cost hardware | Higher-self-sufficiency reference hardware | Gross voltage <0.95 h | Minimum-cost voltage <0.95 h | Higher-SS voltage <0.95 h |
|:--|--:|--:|--:|--:|--:|--:|
| A0 | 110 | 15 | 3 | 43 | 5 | 2 |
| A1 | 25 | 2 | **1** | 3 | 0 | 0 |

Relative to A0 gross-load territory-hours, A1 higher-SS reduces the count **110 to 1 (99.09%)**. The remaining A1 higher-SS violation is a **transformer overload at 106039**, not a voltage violation. This is a substantial modelled improvement, not an all-year AC-feasible final result. A0 min-cost PV+BESS leaves 5 undervoltage hours on 94022 and 10 overload hours on 106039; the A0 higher-SS reference leaves 2 voltage hours on 94022 and 1 overload hour on 106039. A1 min-cost has one overload hour on 106039 and one overload hour on 113699; A1 higher-SS resolves the latter.

Annual modelled LV losses in the five territories (PF0.98 x1.0, 92395 STAR):

| Grouping | Gross load | Minimum-cost PV+BESS | Higher-SS PV+BESS |
|:--|--:|--:|--:|
| A0 | 2,187.69 kWh | 1,753.06 kWh | 1,707.05 kWh |
| A1 | 2,126.51 kWh | 1,715.65 kWh | 1,678.97 kWh |

These are electrical-model losses. They were **not fed back into source capacity optimization, and their value was not fully included in annual cost**. Every AC case uses fixed P injection from energy dispatch with an assumed **daylight Q ratio 0.25**, nighttime Q disabled. Voltage/loading results depend on this assumed reactive-power model and on provisional EPM service and equipment conditions. Manufacturer proof for Q capability at all tested operating points remains absent.

## 3. Robustness across PF and service-routing uncertainty

The complete 432 AC replays span **48 unique hardware/topology/dispatch combinations x nine** combinations of PF 0.95,0.98,1.00 and service factors x1.0,x1.3,x1.6. Zero numerical nonconvergence does not mean zero voltage or transformer violations.

At the toughest tested PF=0.95 and length x1.6, with 92395 STAR and optimized equipment dispatch, the comparable **34-house five-territory** results are:

| Grouping | Gross-load territory-hours | Min-cost PV+BESS | Higher-SS PV+BESS |
|:--|--:|--:|--:|
| A0 | 421 | 62 | 16 |
| A1 | 86 | 9 | **2** |

Thus **A1 higher-SS still has violations under the reference and worst tested sensitivity**. No selected A1 reference tier can be declared robustly AC-feasible over all nine combinations, and network-constrained redispatch/hardware refinement remains necessary.

## 4. Transformer 92395: proposed STAR versus MST

This is a separate topology experiment, not EPM-confirmed wiring. The four-house association is unchanged between A0 and A1. The proposed network lengths at x1.0 are approximately **STAR 1,153.16 m** and **MST 549.82 m**, so a shorter total wire length does not imply a better feeder voltage envelope when power concentrates on shared branches.

For the **new four-house** minimum-cost design with optimized dispatch, at PF=0.95 length x1.6:

| Topology | Gross-load AC violations | PV+BESS AC violations | Minimum voltage with PV+BESS |
|:--|--:|--:|--:|
| STAR | 0 h | **0 h** | 0.95496 pu |
| MST | 277 h | **110 h** | 0.93161 pu |

The alternative higher-SS four-house design reduces the MST result only to **105 violating hours**. The STAR case has zero main AC violations under all tested PF and length combinations, but real conductor, protection, construction-cost and route evidence are missing. A future Study B comparison must model actual cable costs, conductor sizing and alternative branches rather than declaring STAR automatically preferred.

## 5. Annual equipment/energy economics: use correct comparisons

The original source economics are **USD**, with the historical HOMER/PyPSA assumptions and without verified civil, protection and interconnection costs. The 22 energy cases are separate cohorts/tiers; `higher-SS` refers to hardware selection *intent/reference*, not a universally achieved 90.0% after matching geographic profiles. For example, the A1 94022 higher-SS reference achieved **89.9908%**, slightly under 90%.

To compare one 34-house A0 or A1 architecture consistently, sum **four archived-reference geographic cohorts** plus **one new 92395 four-house** design. This is an illustrative sum of the five proposed independent shared installations, not one 34-house centrally optimized mini-grid. STAR/MST do not change the annual *energy-only* values because topology is applied in AC, not the PyPSA capacity design.

| Grouping and hardware tier | Annual energy self-sufficiency | Grid import | Modelled annual energy/equipment cost |
|:--|--:|--:|--:|
| A0 minimum cost | 82.89% | 11,039.9 kWh | $13,783.15 |
| A0 higher SS | 92.89% | 4,586.5 kWh | $14,952.74 |
| A1 minimum cost | 81.92% | 11,665.8 kWh | $13,750.91 |
| A1 higher SS | 90.98% | 5,821.7 kWh | $14,647.02 |

A1 minimum-cost versus A1 higher-SS increases annual modelled cost by **$896.11/year (6.5%)**, improves modelled self-sufficiency by **9.06 percentage points**, and changes reference-case AC violation territory-hours **2 to 1**. This is a technology/energy-screen tradeoff, **not** a network-constrained global minimum, because installation costs, engineering controls and several alternative equipment choices remain unpriced/unoptimized.

For the 92395 new four-house design, the new cost-minimizing MILP case is **17 panels / 3 battery modules / 5 kVA inverter**, 89.76% self-sufficiency and **$1,638.64/year**. The new higher-SS case uses **17 panels / 4 modules / 5 kVA** for 93.10% and **$1,711.69/year**. For A0 113699 and 85398, the new four-house MILP design is a distinct evidence stream from borrowed historical five-house hardware proxies. `hardware_family` must remain a mandatory figure/CSV key.

## 6. Causal versus perfect-foresight operation

The compact summaries show optimized and causal dispatches had near-identical annual imports in all 22 energy pairs. This **does not establish identical hourly operation or AC performance**. The 106039 A0 min-cost reference at PF0.98 x1.0 has **10 violation hours with optimized** and **12 with causal** operation. The annual energy objective cannot by itself ensure a feasible network injection at every hour.

Two A0 borrowed four-house higher-SS causal replays ended with a greater battery SOC than they started: **113699 +4.9711 kWh** and **85398 +3.4640 kWh**. Their annual energy import comparisons with cyclic PyPSA require explicit terminal-state normalization before claiming equivalent year-end service or cost. No SOC-drift issue was found for the six separately optimized `four_house_new` causal summaries after recovering their `terminal_soc_delta_kwh` from the correct source field.

## 7. What is completed and what still needs work

**Completed, conditional research evidence:** gross 90-case baseline, 22 fixed/new capacity energy simulations, 22 causal dispatches, 432 annual AC replays, nine sensitivities per unique AC design/dispatch, independent matching against baseline and reconciliation of collector metadata. No new simulations are needed to repair the 72-row metadata-key false positive.

**Not completed or field-certified:** AC-constrained global equipment optimization; elimination of the final A1 106039 overload hour; loss-aware costs; inverter Q capability verification; as-built 92395 connections; phase imbalance, protection and line ampacity/cost verification; annual causal terminal-SOC normalization for the two exceptions; community-wide islanded outage resilience; Studies B and C.

## 8. Proposed figure decisions before any new plots

In keeping with the user's editorial rule, **do not generate figures simply because data are available**. Before creating each, agree its comparison and visual encoding. Recommend preserving existing `case1/professor_walkthrough/` historical stages 01–11 and extending the progressive research narrative:

1. **New stage 12, topology evidence:** side-by-side A0/A1 EPM LV topology with mapped EPM sections versus assumed service links, and the three moved households. The original 01_EPM_mapped_LV_topology should be preserved; place the new figure beside it with a distinct name.
2. **Stage 13, AC feasibility transition:** compared like-for-like transformer-territory annual violation hours gross -> minimum-cost PV+BESS -> higher-SS. Separate A0/A1, shared PF0.98 x1.0; simple paired dots or clean horizontal bars. Headline result is A0 gross 110 to A1 higher-SS 1, with caveat on territory-hours and remaining overload.
3. **Stage 13, robustness:** two-by-two compact heatmap or paired line chart comparing A0/A1 and min-cost/higher-SS over the same 3x3 PF/length grid. One consistent colour scale, no duplicate curves. Highlight strongest stress case A1 higher-SS 2 versus gross 86.
4. **Stage 12 or 14, physical topology choice:** 92395 STAR/MST gross/PV+BESS at PF0.95 and length x1.0/x1.3/x1.6, with total proposed conductor lengths in a caption. Stress example MST 277->110 h and STAR 0->0 h; do not confuse cable length with voltage performance.
5. **Stage 13, operational trade-off:** reuse the existing monthly-energy composition for 106039 and a four-house cohort, but first request their hourly data if recomputing true monthly energy figures. The uploaded compact ZIP does **not** contain hourly files. A separate, genuinely informative economic scatter could show hardware source family, cost, self-sufficiency and AC violation status without joining discrete MILP alternatives with misleading lines.
6. **Stages 14–16:** B new network, C Site A, resilience defined by critical-load service during outage. These are later research, not illustrated as simulated results prematurely.

**No new figures generated in this audit. No GitLab writes.**

## Reproducibility

`studya_final_analysis.py` reads the uploaded collector ZIP plus the audited 90-case gross CSV, performs cross-source unique-key, input SHA, convergence and gross-to-PVBESS matching assertions, reconstructs only source-present missing cost and causal tier fields, and creates the corrected append-only CSV/JSON derived tables. It is read-only with respect to its inputs and GitLab.
