# Study A final portfolio independent review, 16 November 2026

Read `RESEARCH_REVIEW.md` first. The uploaded original compact final ZIP is not included to avoid duplication. No new simulation or optimization is performed.

## Included outputs

- `QA_CORRECTED_REPORT.json` for case audit status and source-level limitations.
- `AC_432_CORRECTED_UNIQUE_CASES.csv`: all 432 original case records with a correct `hardware_family` and unique identity.
- `AC_GROSS_PVBESS_PAIRED_432.csv`: correct gross versus PV+BESS comparison across all 432 annual AC cases, matched by cohort, PF, routing topology and length.
- `MAIN_AC_GROSS_VS_PVBESS_PF098_L10_20_DESIGNS.csv`: selected optimized-dispatch baseline comparisons.
- `FIVE_TERRITORY_STAR_AGGREGATE_COMPARISON_36.csv`: five-territory 34-house comparison across both groupings, two reference tiers and nine sensitivities, using STAR for unchanged 92395.
- `ENERGY_22_RECONCILED_COSTS.csv`: corrected costs for six new four-house cases from their original saved model summaries; source differentiation preserved.
- `ENERGY_OPTIMIZED_VS_CAUSAL_22.csv`: dispatch comparisons and SOC termination notes.
- `GROSS_90_CASE_REFERENCE.csv`: prior reference used for matching.
- `studya_final_analysis.py`: assertions and reproducible read-only derivation.

To reproduce the review tables, using Python with `pandas` and `numpy` installed:

```bat
python studya_final_analysis.py --archive "StudyA_PVBESS_Annual_Result_Summary_FINAL.zip" --gross "GROSS_90_CASE_REFERENCE.csv" --out "StudyA_reprocessed"
```

The source compact collector archive contains no raw hourly CSV data. Its original collection procedure verified the raw files locally and embedded their signed checksums and chronology in `CASE_INVENTORY.csv`. This independent step checks those records and signed summary identities, but cannot replace an independent numerical model run or a full hourly physics audit.

The collector's 72 duplicate-dimension flags are an identification-key error, not a reason to exclude or rerun the 72 valid cases. The 6 four-house energy cost omissions and the 6 four-house causal tier omissions are likewise corrected from existing signed summaries and case names, not invented.

## Optional targeted hourly evidence (for next-stage analyses)

The final compact uploaded archive does not contain the hourly records necessary to identify exact violating timestamps, validate the daily reactive dispatch profile, or prepare new 12-month energy charts. To provide only selected hourly cases, save `collect_selected_hourly_evidence.py` at the repository root and run:

```bat
python collect_selected_hourly_evidence.py --repo-root . --out StudyA_Selected_Annual_Hourly_Evidence.zip
```

This read-only collector bundles 10 targeted AC yearly cases and seven pairs of energy/causal yearly cases, after checking their original signed SHA-256 hashes. It does not rerun simulations or overwrite outputs. Upload the result for exact-hour feasibility and monthly figure planning. If it reports a filename or hash error, preserve the original files and share the printed exception.
