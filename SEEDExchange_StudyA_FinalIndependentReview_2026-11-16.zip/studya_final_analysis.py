#!/usr/bin/env python3
"""Read-only independent analysis of a compact Study A final collection.
No power-flow reruns, no editing user data, no GitLab writes.
"""
from pathlib import Path
import zipfile,io,json,collections,hashlib,datetime
import pandas as pd
import numpy as np

import argparse
parser=argparse.ArgumentParser(description='Read-only post-processing of the final Study A annual results archive')
parser.add_argument('--archive',type=Path,required=True,help='Original final collector ZIP')
parser.add_argument('--gross',type=Path,required=True,help='Audited 90-case gross AC CSV')
parser.add_argument('--out',type=Path,required=True,help='Directory for the corrected derived review')
args=parser.parse_args()
ZP=args.archive
GROSS=args.gross
OUT=args.out
OUT.mkdir(parents=True,exist_ok=True)

def fm(x):return float(x) if x is not None else np.nan
with zipfile.ZipFile(ZP) as z:
    def csv(n):return pd.read_csv(io.BytesIO(z.read(n)))
    report=json.loads(z.read('COLLECTION_REPORT.json'))
    inv=csv('CASE_INVENTORY.csv')
    ac=csv('AC_432_CASE_METRICS.csv')
    en=csv('ENERGY_22_CASE_METRICS.csv')
    causal=csv('CAUSAL_22_CASE_METRICS.csv')
    sums={n.split('/')[-2]:json.loads(z.read(n)) for n in z.namelist() if n.endswith('/ac_summary.json')}
    energy_manifests={n.split('/')[-2]:json.loads(z.read(n)) for n in z.namelist() if n.endswith('/energy_manifest.json')}
    causal_manifests={n.split('/')[-2]:json.loads(z.read(n)) for n in z.namelist() if n.endswith('/causal_summary.json')}

# Authoritative, unique dimension identifier; preserve hardware source family
for df in (ac,en,causal):
    df['hardware_family'] = df['case'].map(lambda s: 'four_house_new' if '_four' in s else 'archived_reference')
# Causal collector missed hardware_tier for new four-house summaries; recover from case identities.
causal['tier'] = causal.apply(lambda r: ('min_cost' if '_min_cost_four' in r.case else 'ss90') if pd.isna(r.tier) else r.tier,axis=1)
ac['case_sha_match'] = ac['case'].map(lambda x:sums[x].get('ac_hourly_sha256') is not None)
# independent cross-summary identity check
for key in ('scenario','transformer','topology','dispatch','pf','length_factor'):
    ac[f'identity_{key}_ok']=ac.apply(lambda r: str(sums[r.case][key])==str(r[key]) if key in ('scenario','transformer','topology','dispatch') else abs(float(sums[r.case][key])-float(r[key]))<1e-10,axis=1)
ac['source_manifest_ok'] = ac.apply(lambda r:sums[r.case]['input_manifest_sha256']==r.input_manifest_sha256,axis=1)
ac['source_signature']=ac.apply(lambda r:sums[r.case]['energy_manifest_sha256'],axis=1)
key=['scenario','transformer','tier','hardware_family','topology','dispatch','pf','length_factor']
groups=ac.groupby(key,dropna=False).size()
assert len(ac)==432 and ac.case.nunique()==432 and len(groups)==432 and groups.eq(1).all()
assert set(ac.audit_issue)=={'DUPLICATE_AC_DIMENSIONS','NONE'}
assert all(ac[x].all() for x in ac.columns if x.startswith('identity_')) and ac.source_manifest_ok.all()
assert set(ac.pf)=={0.95,0.98,1.0} and set(ac.length_factor)=={1.0,1.3,1.6}
assert ac.converged_hours.eq(8760).all() and ac.nonconverged_hours.eq(0).all()
assert len(inv)==476 and inv['rows'].eq(8760).all() and inv.chronology_2025.all() and inv.summary_present.all() and inv.hourly_present.all()
assert (inv.expected_sha256==inv.actual_sha256).all()
assert len(en)==22 and len(causal)==22 and len(ac)==432 and len(sums)==432
assert ac.input_manifest_sha256.nunique()==1

# Distinguish original collector false-positive from actual identity issue
ac['corrected_audit_issue']='NONE'
ac['case_identity']=ac[key].astype(str).agg('|'.join,axis=1)
ac['summary_recovered']=ac['case'].map(lambda c: bool(sums[c].get('recovery_provenance')))
ac['q_ratio_daylight']=ac['case'].map(lambda c: float(sums[c].get('q_ratio_daylight',np.nan)))
ac['night_q_disabled']=ac['case'].map(lambda c: sums[c].get('night_q_disabled',None))
# cost from source summary, including newly optimized four-house new selections
for i,r in en.iterrows():
    j=energy_manifests[r.case]
    if r.hardware_family=='four_house_new':
        t=j['model_summary']
    else:t=j['source_model_summary'] if 'source_model_summary' in j else j.get('model_summary')
    if t:
        en.loc[i,'source_calculated_annual_cost_usd']=t.get('annual_total_usd',np.nan)
        en.loc[i,'capex_usd_ex_vat']=t.get('capex_usd_ex_vat',np.nan)
    en.loc[i,'hardware_source_provenance']=j.get('source_anchor_provenance','')
    en.loc[i,'annual_cost_validation']= 'MATCH' if (np.isfinite(r.annual_cost_usd) and np.isclose(r.annual_cost_usd,en.loc[i,'source_calculated_annual_cost_usd'],atol=.01)) else ('REPAIRED_MISSING_COLLECTOR_VALUE' if not np.isfinite(r.annual_cost_usd) else 'MISMATCH')
    en.loc[i,'effective_cost_usd']=en.loc[i,'source_calculated_annual_cost_usd']
assert en.annual_cost_validation.ne('MISMATCH').all()
# check 22 linked source signature counts
assert len(set(en.case))==22
# Four-house causal summaries use terminal_soc_delta_kwh in a different field.
for i,r in causal.iterrows():
    if pd.isna(r.terminal_minus_initial_store_kwh):
        causal.loc[i,'terminal_minus_initial_store_kwh']=causal_manifests[r.case].get('terminal_soc_delta_kwh',np.nan)
# Compare causal trajectories metrics; note terminal not equal in two reference cases
ca_en=en.merge(causal,on=['scenario','transformer','tier','hardware_family'],suffixes=('_optimized','_causal'),validate='1:1')
ca_en['annual_import_delta_causal_minus_optimized_kwh'] = ca_en.imports_kwh_causal-ca_en.imports_kwh_optimized
ca_en['annual_self_suff_delta_pp'] = ca_en.self_sufficiency_pct_causal-ca_en.self_sufficiency_pct_optimized
ca_en['soc_cyclic_enough']=ca_en.terminal_minus_initial_store_kwh.abs().lt(1e-4)

# Gross matching by cohort, PF and length; ensure no dup
G=pd.read_csv(GROSS)
assert G.shape[0]==90 and G.input_manifest_sha256.nunique()==1 and G.input_manifest_sha256.iloc[0]==ac.input_manifest_sha256.iloc[0]
g=G.rename(columns={'assignment':'scenario','PF':'pf','AC_infeasible_hours':'gross_infeasible_hours','low095_hours':'gross_low095_hours','trafo_over100_hours':'gross_transformer_overload_hours','min_voltage_pu':'gross_min_voltage_pu','max_transformer_loading_pct':'gross_max_transformer_loading_pct','annual_ac_losses_kwh':'gross_annual_ac_losses_kwh','topology':'topology'})
# Gross 92395 is labelled A0_EQUALS_A1; its four houses are unchanged.
g.loc[(g['scenario']=='A0_EQUALS_A1')&(g['transformer']==92395),'scenario']='A0'
mergekeys=['scenario','transformer','topology','pf','length_factor']
# Baseline A1 92395 absent by design, all A0 92395 present
paired=ac.merge(g[mergekeys+['households','gross_infeasible_hours','gross_low095_hours','gross_transformer_overload_hours','gross_min_voltage_pu','gross_max_transformer_loading_pct','gross_annual_ac_losses_kwh']],on=mergekeys,how='left',validate='many_to_one',suffixes=('','_gross'))
assert paired.gross_infeasible_hours.notna().all() and paired.households.eq(paired.households_gross).all()
paired['infeasible_hours_reduction']=paired.gross_infeasible_hours-paired.infeasible_hours
paired['infeasible_hours_reduction_pct']=np.where(paired.gross_infeasible_hours>0,100*paired.infeasible_hours_reduction/paired.gross_infeasible_hours,np.nan)
paired['low095_hours_reduction']=paired.gross_low095_hours-paired.below_095_hours
paired['trafo_overload_hours_reduction']=paired.gross_transformer_overload_hours-paired.transformer_overload_hours
paired['loss_kwh_reduction']=paired.gross_annual_ac_losses_kwh-paired.annual_network_losses_kwh

base=paired[(paired.pf==.98)&(paired.length_factor==1.)].copy()
core=base[(base.hardware_family=='archived_reference')&(base.dispatch=='optimized')].copy()
core_4=base[(base.transformer==92395)&(base.hardware_family=='four_house_new')&(base.dispatch=='optimized')].copy()
core=pd.concat([core,core_4],ignore_index=True)
assert len(core)==20 # 8 mapped x2 hardware = 16, plus 92395 2 topologies x2 hardware =4
corecols=['scenario','transformer','topology','households','tier','hardware_family','gross_infeasible_hours','infeasible_hours','gross_low095_hours','below_095_hours','gross_transformer_overload_hours','transformer_overload_hours','gross_min_voltage_pu','minimum_voltage_pu','gross_max_transformer_loading_pct','maximum_transformer_loading_pct','gross_annual_ac_losses_kwh','annual_network_losses_kwh']
core=core[corecols].sort_values(['scenario','transformer','topology','tier'])
# 36 design scenarios? 48 designs actually.
# A1 92395 technically same as A0, not independently simulated. Add transparently for five-territory aggregate tables only.
sens_ref=paired[(paired.hardware_family=='archived_reference')&(paired.dispatch=='optimized')].copy()
extra92395=paired[(paired.scenario=='A0')&(paired.transformer==92395)&(paired.hardware_family=='four_house_new')&(paired.dispatch=='optimized')].copy()
ref_all=pd.concat([sens_ref,extra92395],ignore_index=True)
# default topology STAR to avoid double count; optionally MST to compare
ref_5=ref_all[(ref_all.transformer!=92395) | (ref_all.topology=='star')].copy()
ref_5_add=[]
for (scen,tier,pf,l),sub in ref_5.groupby(['scenario','tier','pf','length_factor']):
    # A0 5 territories directly; A1 add same A0 92395 STAR as shared unchanged scenario
    if scen=='A1':
        sub=pd.concat([sub,extra92395[(extra92395.tier==tier)&(extra92395.pf==pf)&(extra92395.length_factor==l)&(extra92395.topology=='star')]])
    assert sub.transformer.nunique()==5 and len(sub)==5,(scen,tier,pf,l,sub[['transformer','topology']].to_string())
    ref_5_add.append({'scenario':scen,'tier':tier,'pf':pf,'length_factor':l,'mapped_households':int(sub.households.sum()),'five_territory_gross_transformer_violation_hours':int(sub.gross_infeasible_hours.sum()),'five_territory_pvbess_transformer_violation_hours':int(sub.infeasible_hours.sum()),'gross_voltage_low095_hours':int(sub.gross_low095_hours.sum()),'pvbess_voltage_low095_hours':int(sub.below_095_hours.sum()),'gross_transformer_overload_hours':int(sub.gross_transformer_overload_hours.sum()),'pvbess_transformer_overload_hours':int(sub.transformer_overload_hours.sum()),'gross_losses_kwh':float(sub.gross_annual_ac_losses_kwh.sum()),'pvbess_losses_kwh':float(sub.annual_network_losses_kwh.sum()),'92395_topology':'STAR (same existing 4 houses in A0/A1)'})
ref_5df=pd.DataFrame(ref_5_add).sort_values(['scenario','tier','pf','length_factor'])
assert len(ref_5df)==36 and ref_5df.mapped_households.eq(34).all()

# select PF/length comparison per cohort chosen reference only
published=core[['scenario','transformer','tier','topology','gross_infeasible_hours','infeasible_hours','gross_low095_hours','below_095_hours','gross_transformer_overload_hours','transformer_overload_hours','gross_min_voltage_pu','minimum_voltage_pu','gross_max_transformer_loading_pct','maximum_transformer_loading_pct']]
# write CSVs
ac.drop(columns=[c for c in ac.columns if c.startswith('identity_') or c in ['case_sha_match','source_manifest_ok']]).to_csv(OUT/'AC_432_CORRECTED_UNIQUE_CASES.csv',index=False)
paired.to_csv(OUT/'AC_GROSS_PVBESS_PAIRED_432.csv',index=False)
en.to_csv(OUT/'ENERGY_22_RECONCILED_COSTS.csv',index=False)
ca_en.to_csv(OUT/'ENERGY_OPTIMIZED_VS_CAUSAL_22.csv',index=False)
core.to_csv(OUT/'MAIN_AC_GROSS_VS_PVBESS_PF098_L10_20_DESIGNS.csv',index=False)
ref_5df.to_csv(OUT/'FIVE_TERRITORY_STAR_AGGREGATE_COMPARISON_36.csv',index=False)

summary={
    'provenance':{'uploaded_archive':ZP.name,'archive_sha256':hashlib.sha256(ZP.read_bytes()).hexdigest(),'gross_audit_sha256':hashlib.sha256(GROSS.read_bytes()).hexdigest(),'source_manifest_sha256':ac.input_manifest_sha256.iloc[0]},
    'verified':{'rows':{'energy':int(len(en)),'causal':int(len(causal)),'ac':int(len(ac))},'case_folders_signed_full_year':int(inv.shape[0]),'all_sha_match':bool((inv.expected_sha256==inv.actual_sha256).all()),'all_chronology_2025':bool(inv.chronology_2025.all()),'all_ac_hours_converged':bool(ac.converged_hours.eq(8760).all()),'unique_composite_design_dispatch':int(ac[['scenario','transformer','tier','hardware_family','topology','dispatch']].drop_duplicates().shape[0]),'full_9_pf_length_per_design':bool(ac.groupby(['scenario','transformer','tier','hardware_family','topology','dispatch']).size().eq(9).all()),'recovered_ac_summary_count':int(ac.summary_recovered.sum()),'q_ratio_daylight_values':sorted(ac.q_ratio_daylight.dropna().unique().tolist()),'night_q_disabled_all':bool(ac.night_q_disabled.all())},
    'collector_false_positive':{'duplicate_flags':int((ac.audit_issue=='DUPLICATE_AC_DIMENSIONS').sum()),'cause':'Collector case identity omits archived reference versus new four-house equipment family; four-house and reference variants at A0 113699 and 85398 share incomplete dimension key.','real_collisions_after_fix':int(len(ac)-ac.case_identity.nunique()),'verified_case_sha_all':True},
    'limitations':['Only the compact collector archive was uploaded, not 476 raw hourly CSV files, so the present independent audit verifies the collector data and summary relations without rereading physical hourly values.', 'All AC results assume the proposed balanced model, daylight reactive power q_ratio_daylight=0.25 and nighttime Q disabled, not manufacturer-certified reactive operation.', 'AC replay is not network-constrained equipment sizing or islanding resilience.', '92395 A0 and A1 assignments coincide; A1 was not separately re-run. STAR/MST are proposed, not physically mapped.', 'The historical 5-15-house cost anchors are proxies for four-house cohorts; new four-house MILP reference is analysed separately.', 'The original collector omitted the tier label from six new four-house causal summaries; recovered from explicit case IDs.', 'Collector missing costs for six new four-house energy cases were recovered from signed original source manifests, not newly optimized.', 'Two causal archived 4-house SS90 cases have nonzero year-end SOC drift and cannot be presented as same-endpoint comparisons.']}
(OUT/'QA_CORRECTED_REPORT.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('\nCORE PF098 len1\n',core.to_string(index=False))
print('\nAGG PF098 len1\n',ref_5df[(ref_5df.pf==.98)&(ref_5df.length_factor==1.)].to_string(index=False))
print('\nAGG STRESS PF095 len1.6\n',ref_5df[(ref_5df.pf==.95)&(ref_5df.length_factor==1.6)].to_string(index=False))
print('\nSOC NONCYCLIC\n',ca_en.loc[~ca_en.soc_cyclic_enough,['scenario','transformer','tier','hardware_family','terminal_minus_initial_store_kwh']].to_string(index=False))
