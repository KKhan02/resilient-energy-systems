# SEEDExchange WP1: full-year worst-case voltage review, v1.5

This is an **additive, read-only figure and audit patch**. It does not overwrite previous studies or simulate new operating conditions. It corrects v1.4's hard-coded `77 sampled hours` title and clipped color scale when processing a `mode=full`, 8,760-hour dataset. It uses distinct duration, band-comparison and monthly-failure plots rather than a one-cell heatmap.

Place `plot_annual_voltage_sensitivity.py` and its test under the existing `case1/studies/ac_aware_redispatch_v1/` folder in the local GitLab checkout. Run from the repository root:

```powershell
python -m pytest -q case1/studies/ac_aware_redispatch_v1/tests
python case1/studies/ac_aware_redispatch_v1/plot_annual_voltage_sensitivity.py --robustness-dir case1/studies/ac_aware_redispatch_v1/outputs/seven_robustness_worst_full_01 --outdir case1/studies/ac_aware_redispatch_v1/outputs/seven_worst_full_corrected_figures_01
```

The 4 November 2026 supplied full-year source (`seven`, transformer `94022`, PF 0.90, service-length ×1.6) shows 8,760 AC power-flow convergences, 111 hours below 0.97 pu, none below 0.95 pu, lowest voltage 0.960979 pu, maximum transformer loading 64.60% and maximum line loading 9.84%. All 111 strict-band failures are between 18:00 and 22:00 with zero modelled PV availability. Modelled AC losses are 422.15 kWh, but they are not in the PyPSA dispatch/economic objective.

## Engineering interpretation

- This is a full-year *modelled voltage-magnitude* screen, not formal Colombian/EPM connection compliance.
- The original 0.97–1.03 pu band was an unverified strict research requirement, not a regulatory floor.
- For the accepted 0.95–1.05 pu study target, the fixed seven-house dispatch passes under the examined worst-case PF/route assumptions. That does **not** establish that another year, stochastic load, phase imbalance or field wiring would pass.
- The analysis does not include new SOC optimization or battery/equipment sizing. No further storage should be specified solely to correct the 111 failures at 0.97 pu without an approved stricter voltage-margin objective.
- Next research gate: apply the same voltage band and manufacturer-based SOC to 106039 and to the PV/BESS/inverter and household hosting comparisons. Test actual nameplate, conductor and connection uncertainty separately. When evaluating alternative hardware, independently rerun 8,760-hour AC power-flow for shortlisted designs.

## Source integrity

The script compares each reclassified 0.97–1.03 pu pass count and minimum voltage against the saved `sensitivity_scenarios.csv` and refuses missing or duplicated full-year hourly indices.
